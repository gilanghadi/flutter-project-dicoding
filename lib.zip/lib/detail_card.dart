// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';

// ignore: camel_case_types
class detailcard extends StatelessWidget {
  const detailcard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            SafeArea(
              child: Stack(
                children: <Widget>[
                  Image.asset('assets/img/img-card3.jpg'),
                  SafeArea(
                    child: Container(
                      margin: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      child: IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Icons.arrow_back,
                          color: Color.fromARGB(255, 99, 99, 99),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              width: size.width / 1,
              child: Container(
                margin: const EdgeInsets.only(top: 30, left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    const Text(
                      'Hepbourn Lounge Chair',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromARGB(255, 99, 99, 99),
                          fontFamily: 'Ubuntu'),
                    ),
                    Container(
                      margin: const EdgeInsets.only(right: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                        boxShadow: const [
                          BoxShadow(
                            offset: Offset(0, 4),
                            color: Color.fromARGB(255, 99, 99, 99),
                            blurRadius: 10,
                          )
                        ],
                      ),
                      child: Expanded(
                        child: Stack(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 10, right: 10, top: 6, bottom: 6),
                              child: Row(
                                children: const <Widget>[
                                  Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  Text(
                                    '5.5',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 20.0,
                                        color: Color.fromARGB(255, 99, 99, 99)),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 70),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 30),
                child: Text(
                  'This comfortable chair is traditionally manufactured in a beech wood frame and can be upholstered in a variety of different fabrics with optional button back detailing.',
                  style: TextStyle(fontSize: 18.0, fontFamily: 'Questrial'),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 60),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: FlatButton(
                    onPressed: () {},
                    child: const Text(
                      '\$640',
                      style: TextStyle(fontFamily: 'Ubuntu', fontSize: 20.0),
                    ),
                  ),
                ),
                SizedBox(
                  width: size.width / 2,
                  height: 82,
                  child: FlatButton(
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                      ),
                    ),
                    onPressed: () {},
                    color: const Color.fromARGB(255, 255, 57, 150),
                    child: const Text(
                      'Add To Cart',
                      style: TextStyle(fontFamily: 'Ubuntu', fontSize: 20.0),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
