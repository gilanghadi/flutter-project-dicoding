// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';

class CarouselSlide extends StatelessWidget {
  const CarouselSlide({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: const <Widget>[
          slider(
            image: 'assets/img/slider_1.jpg',
            discount: '30% off',
            title: 'Hepbourn Lounge Chair',
          ),
          slider(
            image: 'assets/img/slider_2.jpg',
            discount: '30% off',
            title: 'Hepbourn Lounge Chair',
          ),
          slider(
            image: 'assets/img/slider_3.jpg',
            discount: '30% off',
            title: 'Hepbourn Lounge Chair',
          ),
          slider(
            image: 'assets/img/slider_4.jpg',
            discount: '30% off',
            title: 'Hepbourn Lounge Chair',
          ),
        ],
      ),
    );
  }
}

// ignore: camel_case_types
class slider extends StatelessWidget {
  const slider({
    Key? key,
    required this.discount,
    required this.image,
    required this.title,
  }) : super(key: key);

  final String image, title, discount;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SizedBox(
            width: size.width * 0.5,
            height: 170,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                Padding(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Stack(
                      children: <Widget>[
                        Expanded(
                          flex: 1,
                          child: Image.asset(
                            image,
                            fit: BoxFit.cover,
                            width: 350.0,
                          ),
                        ),
                        Positioned(
                          top: 0.0,
                          left: 0.0,
                          right: 0.0,
                          bottom: 0.0,
                          child: Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color.fromARGB(48, 122, 101, 101),
                                  Color.fromARGB(0, 37, 37, 37),
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                            ),
                            padding: const EdgeInsets.symmetric(
                                vertical: 30.0, horizontal: 30.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "$title\n",
                                  style: const TextStyle(
                                    color: Color.fromARGB(255, 134, 134, 134),
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Ubuntu',
                                  ),
                                ),
                                const Padding(
                                  padding: EdgeInsets.only(top: 20),
                                ),
                                Text(
                                  '$discount\n',
                                  style: const TextStyle(
                                    color: Color.fromARGB(255, 235, 231, 231),
                                    fontSize: 40.0,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  padding: const EdgeInsets.all(5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
